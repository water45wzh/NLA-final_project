function m = func_p(x,y)
    m = (x^3)/3 - 1/12;
end