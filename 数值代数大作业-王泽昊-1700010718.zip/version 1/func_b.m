function y = func_b(x,n)
    y = (2*n*sin(pi/n)*(1-cos(2*pi*x)));
end