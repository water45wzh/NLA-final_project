function m = func_u(x,y)
    m = (1-cos(2*pi*x))*sin(2*pi*y) ;
end