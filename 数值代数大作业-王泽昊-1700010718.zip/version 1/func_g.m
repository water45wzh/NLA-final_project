function z = func_g(x,y)
    z = 4*pi^2*(2*cos(2*pi*y)-1)*sin(2*pi*x);
end