function m = func_v(x,y)
    m = -(1-cos(2*pi*y))*sin(2*pi*x);
end